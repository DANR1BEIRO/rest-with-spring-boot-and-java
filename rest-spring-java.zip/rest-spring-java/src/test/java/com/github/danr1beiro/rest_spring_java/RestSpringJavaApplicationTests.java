package com.github.danr1beiro.rest_spring_java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestSpringJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
